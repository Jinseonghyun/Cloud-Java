package test.file;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
/**
 * ���� Ž���⿡�� �ؽ�Ʈ���� �����(C:/Users/user/Desktop/test.txt)
 * ����� ��! ANSI�������� �����ؾ� ��
 * @author user
 *
 */
public class TestFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String result = "";
//		FileInputStream fis = new FileInputStream("C:/Users/user/Desktop/test.txt");
//		
//		Reader in = new InputStreamReader(fis);
//		BufferedReader file = new BufferedReader(in );
		FileReader in = new FileReader("C:/Users/user/Desktop/test.txt");
		System.out.println(in.getEncoding());//MS949
		BufferedReader file = new BufferedReader(in);
		while((result = file.readLine()) != null) {
			System.out.println(result);
		}
	}

}









