package test.emp;

import java.util.ArrayList;
import java.util.Arrays;

public class EmpMgr {
	ArrayList<Emp> emps = new ArrayList();//�ߺ������� ���
	Emp[] temp = new Emp[emps.size()];
	public Emp[] list(Emp[] emps) { // name, phone
		return (Emp[]) this.emps.toArray(temp);// toArray() -> Object[]
	}
	public int list() {
		return emps.size();
	}

	public void add(String name, String phone, String addr) {
		Emp emp = new Emp(name, phone, addr);
		emps.add(emp);//�ߺ� ó��?
	}

	public Emp get(String name) {
		Emp result = null;
//		int size = emps.size();
//		for (int i = 0; i < emps.size(); i++) {
//			if (name.equals(emps.get(i).getName())) {
//				return emps.get(i);
//			}
//		}
		for (Emp emp : emps) {
			if(name.equals(emp.getName()))
					return emp;
		}
		return null;
	}

	public Emp get(int i) {
		// TODO Auto-generated method stub
		return emps.get(i);
	}

	public void set(int i, Emp emp) {
		emps.set(i, emp);
	}

	@Override
	public String toString() {
		return "EmpMgr [no of emps=" + emps.size() + "]";
	}

}
