package test.emp;

public class TestEmp {

	public static void main(String[] args) {
		EmpMgr manager = new EmpMgr(); // file, jdbc ���� ����
		System.out.println("�Ѱ��� : " + manager.list());
		System.out.println(manager);
		manager.add("ȫ�浿", "010-1234-5678", "�����");
		System.out.println(manager);
		System.out.println(manager.get(0));
		Emp emp = manager.get("ȫ�浿");
		emp.setAddr("�޷ս�");
		manager.set(0, emp);
		manager.get(0).print();
		System.out.println(manager);
	}

}
