package test.date;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y = 2002;
		int m = 2;
		int d = 14;
		System.out.println("�� ������ " + y+"��" + m + "��" + d + "��");
		
		Date myBirth = new Date();
		myBirth.setYear(2002);
		myBirth.setMonth(2);
		myBirth.setDay(14);
		System.out.println("�� ������ " + myBirth.getYear()+"��"
					+ myBirth.getMonth() + "��" + myBirth.getDay() + "��");
		
		myBirth.setDay(140);
		System.out.println(myBirth.getDay());

		myBirth.setMonth(-100);
		myBirth.setDay(140);
		System.out.println(myBirth.getDay());
		
		myBirth.setMonth(2);
		System.out.println(myBirth.getDay());

		myBirth.setYear(2000);
		myBirth.setDay(140);
		System.out.println(myBirth.getDay());

		myBirth.setDay(140);
		myBirth.setYear(2002);
		myBirth.print();

		
	}
}
