package test.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 * <pre>
 * Socket Ŭ���̾�Ʈ ���α׷� ����
 * @author �����
 * 1. Socket ����
 * 1-1. Socket client = new S(127.0.0.1, 5555); 
 *        (127.0.0.1 ->localhost)
 * 2. connect() : �ʿ���(ip, port), 1���ܰ迡�� ���������� ����
 * 3. 1���� ��ü���� InputStream/OutputStream�� ����.
 * 3-1. In in = client.getI; Out out = client.getOut
 * 4. input-> read(), output-> write()
 * 4-1. in.read();  out.write();
 * 5. close() <- IO �� ����
 * 5-1. client.close();
 * </pre>
 */
public class TestSocketClient {
	static Socket client;
	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		 System.out.println("Client started...");
		 client = new Socket("192.168.100.57", 5555); 
		 final int port = client.getLocalPort();
		 System.out.println("Connected OK!");
		 InputStream in = client.getInputStream(); 
		 OutputStream out = client.getOutputStream();
		 Target outputTarget = new Target(out, port);
		 Thread outCPU = new Thread(outputTarget);
		 outCPU.start();
		 
		 byte[] buffer = new byte[44];
		 while(true)
		 {
			 int i = in.read(buffer);		 System.out.println("read data = " + new String(buffer));
			 if(i == 0)		break;	 Thread.sleep(3000);
		 }
		 in.close();
		 client.close();
	}
}
class Target implements Runnable{
	OutputStream out;
	int port;
	String data = ""+TestSocketClient.client.getLocalAddress() +">";
	
	public Target(OutputStream out, int port) {		this.out = out;	this.port = port;		
																		this.data = data+port+ ">" + 10;	}
	public void run() {
		Scanner scan = new Scanner(System.in);
		try {
			 while(true) {	 
				 System.out.print("��ȭ����:");
				 data = data + scan.next();
				out.write(data.getBytes());
				out.flush();
				System.out.println(data + "write data = " + 10);
				int i = 0;			if(i == 1)		break;	 Thread.sleep(3000);
			 }
			out.close();
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}





