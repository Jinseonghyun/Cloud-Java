package test.date;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y = 2002;
		int m = 2;
		int d = 14;
		System.out.println("�� ������ " + y+"��" + m + "��" + d + "��");
		
		Date myBirth = new Date();
		// myBirth.y = 2002; myBirth.d = 140;
		myBirth.setYear(2002);
		myBirth.setMonth(2);
		myBirth.setDay(14);
		System.out.println("�� ������ " + myBirth.getYear()+"��"
					+ myBirth.getMonth() + "��" + myBirth.getDay() + "��");
		
		myBirth.setDay(140);
		System.out.println(myBirth.getDay());

		myBirth.setMonth(-100);
		myBirth.setDay(140);
		System.out.println(myBirth.getDay());
		
		myBirth.setMonth(2);
		System.out.println(myBirth.getDay());

		myBirth.setYear(2000);
		myBirth.setDay(140);
		System.out.println(myBirth.getDay());

		myBirth.setDay(140);
		myBirth.setYear(2002);
		myBirth.print();

		Date yourBirth = new Date(y, m, 2000);
		yourBirth.print();

		if (myBirth == yourBirth) {
			System.out.println("== : same");
		}
		if (myBirth.equals(yourBirth)) {
			System.out.println("equals() : same");
		}
		
		Appoint appoint = new Appoint("������", 2002, 2, 14);
		appoint.print();
		System.out.println(myBirth);
		System.out.println(appoint);
		
		System.out.println("----������ Polymorphsm----");
		Date[] date = new Date[3];
		date[0] = new Date();
		date[1] = new Appoint();
		date[2] = new Date();

		((Appoint) date[1]).setSubject("ģ��1����");
		
		for (int i = 0; i < date.length; i++) {
			if (date[i] instanceof Appoint) {
				((Appoint) date[i]).setSubject("ģ��2����");
			}
			date[i].print();
		}
	}
}







