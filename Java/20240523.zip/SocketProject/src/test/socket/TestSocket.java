package test.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;
import java.util.Scanner;

public class TestSocket {

	public static void main(String[] args) throws IOException {
		int port = 5000;
		// TODO Auto-generated method stub
		//1.
		ServerSocket server = new ServerSocket(port);
		System.out.println("Server Init OK");
		//2.
		while (true) {
			Socket service = server.accept();
			System.out.println("Client connect Server port : " + service.getLocalPort());
			System.out.println("Client connect Client IP : " + service.getInetAddress());
			System.out.println("Client connect Client port : " + service.getPort());
			
			//3.
			InputStream in = service.getInputStream();
			OutputStream out = service.getOutputStream();
			int dataClient = in.read();
			System.out.println("Client data : " + (char)dataClient);
			
//			Scanner scan = new Scanner(in);
//			PrintWriter pw = new PrintWriter(out);
			//4. 
//			System.out.println(scan.next());00
//			String data = "Server MSG : end";
//			pw.print(data);
//			//5. 
//			//7. 
//			pw.close();
//			scan.close();
//			service.close();
			if(dataClient ==0) break;
		}
		//8.
		server.close();
	}

}










