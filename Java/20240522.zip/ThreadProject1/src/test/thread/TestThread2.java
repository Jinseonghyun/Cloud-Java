package test.thread;

public class TestThread2 {

	public static void main(String[] args) throws InterruptedException {
		Counter monitor = new Counter();
		Coder target = new Coder(monitor);
		Thread cpu1 = new Thread(target);
		Thread cpu2 = new Thread(target);
		cpu1.start();		cpu2.start();
		cpu1.join();		cpu2.join();
		System.out.println("������ : " + monitor.getCount());
	}

}
