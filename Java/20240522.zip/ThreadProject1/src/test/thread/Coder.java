package test.thread;

public class Coder implements Runnable {
	Counter monitor;
	public Coder(Counter monitor) {
		this.monitor = monitor;
	}

	@Override
	public void run() {
		for (int i = 0; i < 100000000; i++) {
			monitor.inc();
		}
	}

}
