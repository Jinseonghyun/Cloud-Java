package test.thread;

public class TestThread1 {

	static int count = 0;
	public static void main(String[] args) throws InterruptedException {
		Thread cpu = new Thread(new Runnable() {
			public void run() {  	for (int i = 0; i < 100000000; i++) {	count++;	}
				System.out.println(count);
			}
		});

		Thread cpu1 = new Thread(new Runnable() {
			public void run() {  	for (int i = 0; i < 100000000; i++) {	count++;	}
			System.out.println(count);
		}
	});
		cpu.start();		cpu1.start();
		cpu.join();			cpu1.join(1000);
		System.out.println("������ : " + count);
	}
}




