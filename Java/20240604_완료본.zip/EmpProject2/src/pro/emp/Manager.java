package pro.emp;

import java.util.ArrayList;

public class Manager extends Employee {
		private static double tax = 0.05;
	  ArrayList<Employee> emps = new ArrayList();
	  //getter/setter
	  public void addEmp(Employee e){
		  emps.add(e);
	  }
	  public Employee removeEmp(Employee e){
		  emps.remove(e);
		  return e;
	  }
	  public Employee removeEmp(int no){
		  return emps.remove(no);
	  }
		@Override
		public String toString(){
			return super.toString() + "\n\t ����("+ toStringTeam() + ")";
		}
	  private String toStringTeam() {
		  String result = "";
		  for (Employee emp : emps) {
			result += emp.getName() + " : " + emp.getClass() + "/";
		}
			return result;
		}
	public int getNoEmps(){
		  return emps.size();
	  }
	  public int getBonus(long salesQ){
	    double ratio = 0.0, dr = 0, a,b = 0;
	    System.out.println(getName() + "���� �� : " + emps.size());
	    for(Employee emp : emps){
		    System.out.print("�󿩱� �� : " + ratio);
		    a = emp.getBonus(salesQ);
		    b = emp.getSalaryM();
		    dr = a/b;
//		    dr = emp.getBonus(salesQ)/emp.getSalaryM(); // �̷��� �ϸ� �ȵǴ� ������ ã�� ������.
	    	ratio += dr;
//		    System.out.println("-> �󿩱�("+emp.getBonus()+"/"+emp.getSalaryM()+")�� �λ��: " + dr);
	    } 
	    System.out.println(getName() + "�󿩱� �� : " + ratio);
	    setBonus((int) (getSalary() /12 *ratio));
	    return getBonus();
	  }
	  Manager(){}
	  Manager(String name, String phone, int salary){
	    super(name, phone, salary);
	  }
	  public double getTax() {
		return tax;
	  }
}
