package pro.emp;

import java.sql.Date;
import java.util.Calendar;

public class Engineer extends Employee {
	  private static double tax = 0.10;
	  public int getBonus(long salesQ){
		  //6��������(���� ��� 6��, 12��) ������ 5%��
		   int month = Calendar.getInstance().get(Calendar.MONTH)+1;
		int result;
		if(month%6 == 0)
			result = (int) (getSalary()/12*0.05);
		else
			result = 0;
		setBonus(result);
		return getBonus();
	  }

	  public Engineer(){}
	  public Engineer(String name, String phone, int salary){
	    super(name, phone, salary);
	  }
	  public double getTax() {
		return tax;
	  }
}
