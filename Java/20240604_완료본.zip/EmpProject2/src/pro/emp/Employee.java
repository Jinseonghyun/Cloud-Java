package pro.emp;

public abstract class Employee
{  private static int seq;
   private String name, phone;
   private int no, salary, bonus;
   public Employee(){      no = seq++; System.out.print("��� : " + no + "> ");   }
   Employee(String name, String phone, int salary){
     this();
     this.name = name; this.phone = phone;
     this.salary = salary;
   }
   public void print()
   {System.out.println(this);
   }
	@Override
	public String toString(){
		return "���("+no + ")"+ name + "[�ѱ޿� : " + getSalaryM() + "\t������ : " + getSalaryM() * (1- getTax()) + "(���� : " + getTax() + ")" + "\t�⺻�� : " + getSalary()/12 + "\t �󿩱� : " + getBonus() + "]";
	}

	public abstract int getBonus(long salesQ);
	public int getBonus() {
		// TODO Auto-generated method stub
		return bonus;
	}
	public int getNo() {
		return no;
	}
	public String getName() {
		return name;
	}
	public String getPhone() {
		return phone;
	}
	public int getSalary() {
		return salary;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	abstract public double getTax();
	
	protected void setBonus(int bonus) {
		System.out.println(getName() + " :: bonus = " + bonus);
		this.bonus = bonus;
	}

	public int getSalaryM(){    
		return getSalary()/12 + getBonus();  
	}
}