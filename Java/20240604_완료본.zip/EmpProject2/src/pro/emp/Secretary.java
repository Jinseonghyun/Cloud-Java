package pro.emp;

import java.util.ArrayList;

public class Secretary extends Employee {
	  private static double tax = 0.10;
	  public int getBonus(long salesQ){
		  setBonus(0);
		return getBonus();
	  }
	  public Secretary(){}
	  public Secretary(String name, String phone, int salary){
	    super(name, phone, salary);
	  }
	  public double getTax() {
		return tax;
	  }
}
