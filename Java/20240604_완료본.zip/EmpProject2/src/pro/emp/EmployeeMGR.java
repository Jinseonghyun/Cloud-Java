package pro.emp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class EmployeeMGR {
	static long salesQ = 5000000000L;
	static int profit = 2000000000;
	static int no = 0; //�������� ȸ�ǿ� ����
	static HashMap<Integer, Employee> empList = new HashMap();

	public static void main(String[] args) {
		long salesQ = 5000000000L;
		int profit = 2000000000;
		//-. ��ü �ο� : ~20�� -> 
		int noOfEmps = (int) (Math.random()*20+1);
		System.out.println("��ü ���� �� : " + noOfEmps);
		for (int i = 0; i < noOfEmps; i++) {
			// -. ���� �η� : random���� ����
			int empClass = (int) (Math.random()*4);
			createEmployee(empList, empClass, "ȫ�浿", "010-5251-3548", 100000000);
		}
		//�� ����
		createTeam(empList);
		//�޿� ���
		printSalaryOfMonth();
		
		//���޺� �޿� ���
		printSalaryOfMonthByPosition();
		
//			int no = 1;
//		System.out.println("�� ������ �޿�������(��� : "+ no +"�� ����)");
//		Employee emp = empList.get(no);
//		if (emp != null) {
//			emp.print();
//		}
		//���� �޿�������
		for (Employee emp : empList.values()) {
			emp.print();
		}
	}
	private static void printSalaryOfMonthByPosition() {
		System.out.println("�ΰǺ� ���� �հ� : ������/������/�����/����");
		System.out.println(getTotSalaryM(Manager.class, empList)	+"\t"
				+ getTotSalaryM(Sales.class, empList)	+"\t"
				+ getTotSalaryM(Engineer.class, empList)	+"\t"
				+ getTotSalaryM(Secretary.class, empList));
	}
	private static void printSalaryOfMonth() {
		System.out.println("�ΰǺ� ���հ� : �հ�/�����޾�/����");
		int totSalaryM = getTotSalaryM(empList);
		int totActualSalaryM = getTotActualSalaryM(empList);
		int totTax = totSalaryM - totActualSalaryM;		
		System.out.println(totSalaryM  +"\t"+ totActualSalaryM +"\t" + totTax);
	}
	//������
	private static void createTeam(HashMap<Integer, Employee> empList) {
		ArrayList<Manager> mgrs = new ArrayList();
		ArrayList<Employee> emps = new ArrayList();
		for (Employee emp : empList.values()) {
			if (emp instanceof Manager) {
				mgrs.add((Manager) emp);
			}else
				emps.add(emp);
		}
		if(mgrs.size() < 1 || emps.size() == 0) return;
		
		for (Employee emp : emps) {
			Manager mgr = mgrs.get(emp.getNo()%mgrs.size());
			// mgrs�� index == ��ü������ no%�Ŵ������� �� ����.
			mgr.addEmp(emp);
			System.out.println(mgr.getName()+ "�� �߰� : " + emp.getName());
		}
	}

	private static int getTotSalaryM(Class class1, HashMap<Integer, Employee> empList) {
		Collection<Employee> emps = empList.values();
		Collection<Employee> classes = new ArrayList();
		for (Employee emp : emps) {
			if (emp.getClass().equals(class1)) {
				classes.add(emp);
			}
		}
		
		int sum = 0;
		for (Employee emp : classes) {
			sum += emp.getSalaryM();
		}
		
		return sum;
	}

	private static int getTotSalaryM(HashMap<Integer, Employee> empList) {
		Collection<Employee> emps = empList.values();
		System.out.println(emps.size());
		int sum = 0;
		for (Employee emp : emps) {
			emp.getBonus(salesQ);
			sum += emp.getSalaryM();
		}
		
		return sum;
	}

	private static int getTotActualSalaryM(HashMap<Integer, Employee> empList) {
		Collection<Employee> emps = empList.values();
		int sum = 0;
		for (Employee emp : emps) {
			sum += emp.getSalaryM() * (1- emp.getTax());
		}
		
		return sum;
	}

	private static void createEmployee(HashMap empList, int empClass, String name, 
			String phone, int salary) {
		Employee result = null;
		switch (empClass) {
		case 0:
			result = new Manager(name + no++, phone, 120000000);
			break;
		case 1:
			result = new Engineer(name + no++, phone, 72000000);
			break;
		case 2:
			result = new Sales(name + no++, phone, 48000000);
			break;
		case 3:
			result = new Secretary(name + no++, phone, 36000000);
			break;
		}
		empList.put(result.getNo(), result);
		System.out.println("("+result.getClass()+":"+result.getName()+") ��� �Ϸ� : " + result);
	}

}
