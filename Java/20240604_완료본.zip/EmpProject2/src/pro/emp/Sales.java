package pro.emp;

public class Sales extends Employee {
	  private static double tax = 0.10;
	  public int getBonus(long salesQ){
		  setBonus((int) (salesQ*0.005));
		return getBonus();
	  }
	  public Sales(){}
	  public Sales(String name, String phone, int salary){
	    super(name, phone, salary);
	  }
	  public double getTax() {
		return tax;
	  }
}
