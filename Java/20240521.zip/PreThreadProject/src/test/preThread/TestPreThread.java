package test.preThread;

public class TestPreThread {

	public static void main(String[] args) {
		class Target implements Runnable{

			@Override
			public void run() {
				System.out.println(Thread.currentThread());
			}
			
		}
		Thread thread = new Thread(new Target());
		thread.start();
		
		Thread t2 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println(Thread.currentThread());
			}
		});
		t2.start();
		System.out.println(Thread.currentThread());
		
	}

}









