package test.thread;

public class TestThread {

	public static void main(String[] args) {
		Monitor monitor = new Monitor();
		Runnable target = new Target(monitor );
		Thread cpu = new MyThread(target );
		cpu.start();
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread() + ", data=" + monitor);
		}
	}
}
class MyThread extends Thread{					Target target;//Runnable
	public MyThread(Runnable target) {		super(target);		this.target = (Target) target;	}
}
class Target implements Runnable{
	private Monitor monitor;
	public Target(Monitor monitor) {		super();		this.monitor = monitor;	}
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread() + ", data=" + monitor);
		}
	}
	
}
class Monitor extends Object{
	int data;
}








