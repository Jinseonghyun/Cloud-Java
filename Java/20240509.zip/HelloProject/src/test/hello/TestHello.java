package test.hello;
/**
 * 기본 프로그램 hello 메시지 출력
 * @author 진성현
 *
 */
public class TestHello {
	/**
	 * 메인 함수로 command 창에 hello라고 출력할 것임
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "hello"; 
		System.out.println(a);
	}
}
