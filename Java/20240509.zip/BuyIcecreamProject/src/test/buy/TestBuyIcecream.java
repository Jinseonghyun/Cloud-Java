package test.buy;
/**
 * <pre>
1. 나는 꼬마의 왼손에 1000원을 쥐어준다
1-1) left = 1000;
2. 나는 꼬마에게 “누가바 아이스크림을 사와” 라고 말한다
2-1) buyIcecaream(left);
3. 꼬마는 근처 편의점 CU에 간다
3-1) new CU;
4. 꼬마는 점원에게 “누가바 아이스크림 주세요”  하며 왼손의 돈을 내민다
4-1) cu.getIcecream(left);
5. 점원은 아이스크림을 가져와 꼬마의 오른손에 쥐어준다
5-1) return "누가바";
6. 꼬마는 나에게 돌아와 오른손의 누가바 아이스크림을 준다
6-1) syso(right);
 * @author 진성현
 * </pre>
 */
public class TestBuyIcecream {

	public static void main(String[] args) {

		// 1. 나는 꼬마의 왼손에 1000원을 쥐어준다
		int left = 1000;
		// 2. 나는 꼬마에게 “누가바 아이스크림을 사와” 라고 말한다
		String right = buyIcecaream(left);
		// 6. 꼬마는 나에게 돌아와 오른손의 누가바 아이스크림을 준다
		System.out.println(right);
	}

	private static String buyIcecaream(int left) {
		// 3. 꼬마는 근처 편의점 CU에 간다
		CU cu = new CU();
		// 4. 꼬마는 점원에게 “누가바 아이스크림 주세요”  하며 왼손의 돈을 내민다
		String right = cu.getIcecream(left);
		return right;
		
	}
}


