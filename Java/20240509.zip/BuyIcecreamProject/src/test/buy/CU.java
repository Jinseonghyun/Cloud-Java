package test.buy;
// cu 편의점에서 점원이 하는일
public class CU {

	public String getIcecream(int left) {
		//5. 점원은 아이스크림을 가져와 로봇의 오른손에 쥐어준다.
		return "누가바";
	}

}
