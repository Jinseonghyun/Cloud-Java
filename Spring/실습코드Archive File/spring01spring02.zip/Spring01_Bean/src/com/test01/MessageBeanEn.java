package com.test01;

public class MessageBeanEn {
	public void sayHello(String str) {
		System.out.println("Hello, " + str);

	}
}
