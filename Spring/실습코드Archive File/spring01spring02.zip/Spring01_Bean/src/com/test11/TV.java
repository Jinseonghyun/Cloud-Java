package com.test11;

public interface TV {
	void powerOn();
	void powerOff();
}
