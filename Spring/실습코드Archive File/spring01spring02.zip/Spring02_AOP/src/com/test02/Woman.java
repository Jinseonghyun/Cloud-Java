package com.test02;

public class Woman implements Person {

	@Override
	public void classWork() {
		System.out.println("컴퓨터를 켜서 크롬을 실행 한다.");
	}

}
