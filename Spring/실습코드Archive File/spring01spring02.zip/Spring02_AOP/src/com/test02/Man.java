package com.test02;

public class Man implements Person {

	@Override
	public void classWork() {
		System.out.println("컴퓨터를 켜서 노션을 실행 한다.");
	}

}
