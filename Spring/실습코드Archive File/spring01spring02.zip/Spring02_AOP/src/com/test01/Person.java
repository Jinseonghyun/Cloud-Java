package com.test01;

public interface Person {
	void classWork();
}
